#include "helpers.h"

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int r = image[i][j].rgbtRed;
            int b = image[i][j].rgbtBlue;
            int g = image[i][j].rgbtGreen;
            int soma = ( (r + g + b) / 3 );
            image[i][j].rgbtRed = soma;
            image[i][j].rgbtBlue = soma;
            image[i][j].rgbtGreen = soma;
        }
    }

    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    int reflectedR[height][width];
    int reflectedG[height][width];
    int reflectedB[height][width];

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
              reflectedR[i][j] = image[i][j].rgbtRed;
              reflectedG[i][j] = image[i][j].rgbtGreen;
              reflectedB[i][j] = image[i][j].rgbtBlue;
        }
    }

    for (int i = 0; i < height; i++)
    {
        int r = 0;
        for (int j = width; j > 0; j--)
        {
            image[i][j].rgbtRed = reflectedR[i][r];
            image[i][j].rgbtGreen = reflectedG[i][r];
            image[i][j].rgbtBlue = reflectedB[i][r];
            r++;
        }
    }

    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    return;
}

// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    return;
}
